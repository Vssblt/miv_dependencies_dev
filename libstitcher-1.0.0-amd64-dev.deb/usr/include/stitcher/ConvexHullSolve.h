#ifndef CONVEXHULLSOLVE_H
#define CONVEXHULLSOLVE_H
#include <iostream>
#include <cstdio>
#include <vector>
#include <cmath>
#include <algorithm>

typedef struct ConvexHullVector
{
	double x, y;
	int index;
	ConvexHullVector(){}
	ConvexHullVector(double x_, double y_):x(x_),y(y_){}
} ConvexHullPoint;

class ConvexHullSolve
{
public:
	ConvexHullSolve(void);
	~ConvexHullSolve(void);
	double solve();
	static int dcmp(double x);
	void setPoint(ConvexHullPoint *p, int n);
	ConvexHullPoint *getResult();
	int *getIndex();
private:
	double eps;
	int n;
	ConvexHullPoint *p, ch[5000 + 5];
	int index[5000 + 5];
	int convexHull(ConvexHullPoint* p, int n, ConvexHullPoint* ch, int *index);
	double area(ConvexHullPoint a,ConvexHullPoint b,ConvexHullPoint c);
	double dot(ConvexHullVector a, ConvexHullVector b);
	double length(ConvexHullVector a);
	double angle(ConvexHullVector a, ConvexHullVector b);
	double angle(ConvexHullVector v);
	double cross(ConvexHullVector a, ConvexHullVector b);
	double dist(ConvexHullPoint p1,ConvexHullPoint p2);
	friend bool operator == (const ConvexHullPoint& a, const ConvexHullPoint& b);
	friend ConvexHullVector operator + (ConvexHullVector a, ConvexHullVector b);
	friend ConvexHullVector operator - (ConvexHullPoint a, ConvexHullPoint b);
	friend ConvexHullVector operator * (ConvexHullVector a, double p);
	friend ConvexHullVector operator / (ConvexHullVector a, double p);
	ConvexHullPoint ret[3];
	int retIndex[3];
};

#endif
